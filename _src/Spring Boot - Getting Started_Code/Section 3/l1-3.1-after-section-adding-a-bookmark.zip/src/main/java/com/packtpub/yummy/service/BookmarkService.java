package com.packtpub.yummy.service;

import com.packtpub.yummy.model.Bookmark;
import org.springframework.stereotype.Service;

/**
 * Created by pcpacktpub on 07/05/2017.
 */
@Service
public class BookmarkService {

    public void addBookmark(Bookmark bookmark) {

    }
}
