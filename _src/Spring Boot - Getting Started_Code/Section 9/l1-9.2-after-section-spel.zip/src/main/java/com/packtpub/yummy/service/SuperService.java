package com.packtpub.yummy.service;

public interface SuperService {
    void foo();
}
